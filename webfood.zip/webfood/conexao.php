<?php
define('host', 'localhost');
define('user', 'root');
define('pass', '');
define('db', 'dbwebfood');
define('db_set_chart', 'uft8');

	// Protege contra SQL Injetion
	function DBEscape($dados){
		$connect = DBConnect();

		if (!is_array($dados))
				$dados = mysqli_real_escape_string($connect, $dados);
			else{
				$arr = $dados;
				foreach ($arr as $key => $value){
					$key = mysqli_real_escape_string($connect, $key);
					$valeu = mysqli_real_escape_string($connect, $value);
					$dados[$key] = $value;
				}			}
			DBClose($connect);
			return $dados;
	}



	//fecha conexao
    function DBClose($connect){
		@mysqli_close($connect) or die (mysql_error());
	}

	//abre conexao
	function DBConnect(){
		$connect = mysqli_connect(host, user, pass, db)or die (mysqli_connect_error());
		@mysqli_set_charset($connect, db_set_chart);

	return $connect;
	}

?>