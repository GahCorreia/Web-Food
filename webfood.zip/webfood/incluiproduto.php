!DOCTYPE html>
<html ="lang pt-br">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Cadastro</title>

	<!-- CSS -->
	<link type="text/css" rel="stylesheet" href="css/contato-cadastro.css" />

	<!-- JS -->
	<script type="text/javascript" src="js/jquery-1.4.2.min.js"></script>
	<script type="text/javascript" src="js/jquery.cookie.js"></script>
	<script type="text/javascript" src="js/jquery.ui.widget.js"></script>
	<script type="text/javascript" src="js/jquery.ui.core.js"></script>
	<script type="text/javascript" src="js/jquery.ui.mouse.js"></script>
	<script type="text/javascript" src="js/jquery.ui.slider.js"></script>
	<script type="text/javascript" src="js/jquery.ui.tabs.js"></script>
	<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
	<script type="text/javascript" src="js/jquery.mousewheel.min.js"></script>
	<script type="text/javascript" src="js/hoverIntent.js"></script>
	<script type="text/javascript" src="js/jcarousellite_1.0.1.min.js"></script>
	<script type="text/javascript" src="js/jquery.jqtransform.js" ></script>
	<script type="text/javascript" src="js/jquery.jscrollpane.min.js"></script>
	<script type="text/javascript" src="js/utils.js"></script>
	<script type="text/javascript" src="js/jquery.validate.min.js"></script>
	<script type="text/javascript" src="js/jquery.ezpz_tooltip.min.js"></script>

	<!--GA-->

</head>


<body class="interno contato">

	<!--BG-->
	<div id="bg"></div>

	<!--HEADER-->
	<div id="header"></div>

	<!--FAIXA-->
	<div id="faixa">
		<div id="faixaBox">
			<h1>HOME</h1>
			<a class="btnVoltar" href="javascript:history.go(-1)">VOLTAR</a>
		</div>
	</div>

	<!--CONTENT-->
	<h1 align="center"> Bem vindo funcionário!<br /></h1>
	<h2 align="center"> Para cadastrar um novo produto basta clicar em, <a class="btnVoltar" href="formproduto.php">Cadastrar Produto</a><br /></h2>
	<h2 align="center"> Para se alterar ou excluir seus dados cique em, <a class="btnVoltar" href="produtohome.php">Prordutos</a><br /></h2>

	<div class="container"></div>

	<!--FOOTER-->
	<div id="footer"></div>
</body>
</html>
</body>
<?php
 // coloca no index
require 'conexao.php';
require 'database.php';
// Validação de inserção
$erro=0;
$nome       = $_GET["nome"];
$marca		= $_GET["marca"];
$tipo		= $_GET["tipo"];
$quantidade = $_GET["quantidade"];

if (empty($nome)==true){
	echo "<script>alert('Favor digitar o nome do produto');</script>";
	$erro==1;
}

else if (empty($marca) ==true){
	echo "<script>alert('Favor digitar a marca');</script>";
	$erro==1;
}

else if (empty($tipo) ==true){
	echo "<script>alert('Favor selecione o tipo');</script>";
	$erro==1;
}


else if (empty($quantidade) ==true){
	echo "<script>alert('Favor digitar a quantidade');</script>";
	$erro==1;
}

$dados = array(
	'nome' => $nome,
	'marca'=> $marca,
	'tipo'=> $tipo,
	'quantidade'=>$quantidade
	);


if ($erro==0){
	$grava = DBInsert('produto', $dados);
	echo "<script>alert('Produto incluído com sucesso');</script>";
}

else{
	echo  "<script>alert('Não foi possível incluir o produto');</script>";

}
?>