!DOCTYPE html>
<html ="lang pt-br">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Cadastro</title>

	<!-- CSS -->
	<link type="text/css" rel="stylesheet" href="css/contato-cadastro.css" />

	<!-- JS -->
	<script type="text/javascript" src="js/jquery-1.4.2.min.js"></script>
	<script type="text/javascript" src="js/jquery.cookie.js"></script>
	<script type="text/javascript" src="js/jquery.ui.widget.js"></script>
	<script type="text/javascript" src="js/jquery.ui.core.js"></script>
	<script type="text/javascript" src="js/jquery.ui.mouse.js"></script>
	<script type="text/javascript" src="js/jquery.ui.slider.js"></script>
	<script type="text/javascript" src="js/jquery.ui.tabs.js"></script>
	<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
	<script type="text/javascript" src="js/jquery.mousewheel.min.js"></script>
	<script type="text/javascript" src="js/hoverIntent.js"></script>
	<script type="text/javascript" src="js/jcarousellite_1.0.1.min.js"></script>
	<script type="text/javascript" src="js/jquery.jqtransform.js" ></script>
	<script type="text/javascript" src="js/jquery.jscrollpane.min.js"></script>
	<script type="text/javascript" src="js/utils.js"></script>
	<script type="text/javascript" src="js/jquery.validate.min.js"></script>
	<script type="text/javascript" src="js/jquery.ezpz_tooltip.min.js"></script>

	<!--GA-->

</head>


<body class="interno contato">

	<!--BG-->
	<div id="bg"></div>

	<!--HEADER-->
	<div id="header"></div>

	<!--FAIXA-->
	<div id="faixa">
		<div id="faixaBox">
			<h1>HOME</h1>
			<a class="btnVoltar" href="javascript:history.go(-1)">VOLTAR</a>
		</div>
	</div>

	<!--CONTENT-->
	<h1 align="center"> Bem vindo!<br /></h1>
	<h2 align="center"> Para ver nossas pizzas e bebidas clique em, <a class="btnVoltar" href="cardapio.php">, ver Cardapio</a><br /></h2>
	<h2 align="center"> Para se alterar ou excluir seus dados cique em, <a class="btnVoltar" href="clientehome.php">Home Cliente</a><br /></h2>

	<div class="container"></div>

	<!--FOOTER-->
	<div id="footer"></div>
</body>
</html>
</body>
<?php
 // coloca no index
require 'conexao.php';
require 'database.php';


// Validação de inserção
$nome       =$_GET["nome"];
$email		=$_GET["email"];
$cpf		=$_GET["cpf"];
$telefone  	=$_GET["telefone"];
$endereco   =$_GET["endereco"];
$cidade		=$_GET["cidade"];
$uf			=$_GET["uf"];
$cep   		=$_GET["cep"];

$erro=0;
if (empty($nome) ==true){
	echo "<script>alert('Favor digitar o nome completo');</script>";
	$erro==1;
}

else if (empty($email) ==true){
	echo "<script>alert('Favor digitar o e-mail');</script>";
	$erro==1;
}

else if (empty($cpf) ==true){
	echo "<script>alert('Favor digitar o CPF');</script>";
	$erro==1;
}

else if (empty($telefone) ==true){
	echo "<script>alert('Favor digitar o telefone');</script>";
	$erro==1;
}

else if (empty($endereco) ==true){
	echo "<script>alert('Favor digitar o endereço');</script>";
	$erro==1;
}

else if (empty($cidade) ==true){
	echo "<script>alert('Favor digitar a cidade');</script>";
	$erro==1;
}

else if (empty($uf) ==true){
	echo "<script>alert('Favor digitar o UF');</script>";
	$erro==1;
}

else if (empty($cep) ==true){
	echo "<script>alert('Favor digitar o cep');</script>";
	$erro==1;
}

$dados = array(
	'nome' => $nome,
	'email'=> $email,
	'cpf'=> $cpf,
	'telefone'=>$telefone,
	'endereco'=>$endereco,
	'cidade'=>$cidade,
	'uf'=>$uf,
	'cep'=>$cep
	);

if ($erro==0){
	$grava = DBInsert('cliente', $dados);
	echo "<script>alert('Cliente incluido com sucesso');</script>";
}

else{
	echo  "<script>alert('Não foi possível incluir o Cliente');</script>";

	}
?>
</html>