
var selectedUnidade;
var cardapioModalArray;
var mouseInsidePedidos = false;

var device = "";

//If ipad / ipod / iphone
if ((navigator.userAgent.indexOf('iPhone') != -1) || (navigator.userAgent.indexOf('iPod') != -1) || (navigator.userAgent.indexOf('iPad') != -1))
{	
	device = "ios";
}
else
{
	//
}

/*DOCUMENT READY
====================================================================================*/
$(document).ready(function() {
	
	/*FACEBOOK JS SDK
	========================================================================*/
	/*FACEBOOK NORMAL METHOD
	$('body').prepend(	"<!--FACEBOOK JS SDK-->"+
						"<div id='fb-root'></div>"+
						"<script>(function(d, s, id) { var js, fjs = d.getElementsByTagName(s)[0]; if (d.getElementById(id)) return; js = d.createElement(s); js.id = id; js.src = '//connect.facebook.net/pt_BR/all.js#xfbml=1'; fjs.parentNode.insertBefore(js, fjs); }(document, 'script', 'facebook-jssdk'));</script>");
	*/
	
	//FACEBOOK ASYNC METHOD
	$('body').prepend(	"<!--FACEBOOK JS SDK-->"+
						"<div id='fb-root'></div>"+
						"<script type='text/javascript'>"+
						"var cache = jQuery.ajaxSettings.cache;"+// prevent jQuery from appending cache busting string to the end of the FeatureLoader URL
						"jQuery.ajaxSettings.cache = true;"+
						"jQuery.getScript('http://connect.facebook.net/pt_BR/all.js', function() {"+// Load FeatureLoader asynchronously. Once loaded, we execute Facebook init
						"FB.init({appId: 'your_app_id-optional', status: true, cookie: true, xfbml: true});"+
						"});"+
						"jQuery.ajaxSettings.cache = cache;"+// just Restore jQuery caching setting
						"</script>");
	
	
	/*TRACE
	========================================================================*/
	if($('body').hasClass("teste"))
	{
		$('body').prepend("<div id='tracebox'></div>");
	}
	
	
	
	/*TRACE COOKIES
	========================================================================*/
	//set cookie  
	//$.cookie('my_cookie_name', 'Teste de cookie');  
	//get cookie  
	//$.cookie('my_cookie_name')
	//delete cookie  
	//$.cookie('my_cookie_name', null);  
	//$('#tracebox').append($.cookie('baggio-unidade')+'<br/>');
	//$('#tracebox').append($.cookie('baggio-tag')+'<br/>');
	
	
	/*RESIZE
	========================================================================*/
	resizeMe();
	
	
	/*INCLUDES GERAIS
	========================================================================*/
	$('#header').load('includes/include-header.html', function()
	{
		$(".menu > li:not('.pedidos') > a").prepend("<img src='imgs/bullet-white.gif' alt=''/>")
		
		/*LOAD XML*/
		loadXml("unidade","xml/unidades.xml");
	
		/*DISABLE SIMULE PEDIDO - 16/04/13
		//ABRE LISTA
		$("#listaPedidos").append("<ul class='pedido'></ul>")
		
		
		//COMPLEMENTA COM CONTEÚDO DO COOKIE
		$("#listaPedidos .pedido").html($.cookie('baggio-pedido'));
		
		//CONFIG BOT EXCLUIR
		$('#listaPedidos .btnRemove').click(function()
		{
			$(this).parent().remove();
			//SALVAR PEDIDOS EM COOKIE
			$.cookie('baggio-pedido', $("#listaPedidos .pedido").html());  
		})
		
		//MOUSE EVENTS
		$(".pedidos, #listaPedidos").hover(function(){ mouseInsidePedidos = true},function(){ mouseInsidePedidos = false });
		$(".pedidos").click(function(){ $("#listaPedidos").animate({height: 'toggle'}); });
		
		$("body").mouseup(function(){ 
			if(! mouseInsidePedidos) $('#listaPedidos').hide();
		});
		
		if(device != "ios")
		{
			/*TOOLTIP
			========================================================================* /
			$('.tooltip').each(function(tipIndex)
			{
				$(this).attr({'id': 'box-target-'+tipIndex});
				var myDesc = $(this).children('.tooltipDesc').html();
				$('body').append("<div class='tooltipBox' id='box-content-"+(tipIndex)+"'>"+myDesc+"</div>");
			});
			$(".tooltip").ezpz_tooltip({
				contentPosition: 'belowRightFollow',
				offset: 20	
			});
		}
		*/
	});
	
	$('#footer').load('includes/include-footer.html', function(){});
	
	
	/*HOME
	========================================================================*/
	if($('body').hasClass('home'))
	{
		//INCLUDE SIDEBAR
		$('#sideBar').load('includes/include-sidebar-home.html', function(){ $('#redesSociais .compartilhe').load('includes/include-compartilhe.html', function(){}); });
		
		//CONFIG NOVIDADES
		$('#novidades').append("<div class='titleDecoRRed'></div>");
		loadXml("novidades","xml/novidades.xml");
		
		//CAROUSEL PARCEIROS
		$(".parceirosBox .carouselContainer").jCarouselLite({ auto: 2000, speed: 250, visible: 4 });
		
		//MAPS TOGGLE
		$(".encontreBox .icoMap").click(function ()
		{
			$(".encontreMap").animate({width: '360px'});
			$('.encontreBox .icoMap').addClass('selected');
			$('.encontreBox .icoFoto').removeClass('selected');
		});
		$(".encontreBox .icoFoto").click(function ()
		{
			$(".encontreMap").animate({width:'0px'});
			$('.encontreBox .icoMap').removeClass('selected');
			$('.encontreBox .icoFoto').addClass('selected');
		});
	}
	
	
	/*INTERNO
	========================================================================*/
	if($('body').hasClass('interno'))
	{
		$('#faixaBox').append("<div class='compartilhe'></div>");
		$('#faixaBox .compartilhe').load('includes/include-compartilhe.html', function(){});
	}
	
	
	/*BAGGIO
	========================================================================*/
	if( $('body').hasClass('baggio'))
	{
		$('.historico h2, .melhores h2').prepend("<span class='titleDecoLGreen'></span>").append("<span class='titleDecoRGreen'></span>");
	}
	
	
	/*PARCEIROS
	========================================================================*/
	if($('body').hasClass('parceiros'))
	{
		$('.parceirosInfo h2').append("<div class='titleDecoR'></div>");
		
		$('#sideBar').load('includes/include-sidebar-interno.html', function(){ configBoxes(); });
	}
	
	
	/*NOVIDADES
	========================================================================*/
	if($('body').hasClass('novidades'))
	{
		$('#sideBar').load('includes/include-sidebar-interno.html', function(){ configBoxes(); });
		
		loadXml("novidades","xml/novidades.xml");
	}
	
	
	/*FRANQUIAS
	========================================================================*/
	if($('body').hasClass('franquia'))
	{
		var franquiaValidator = $("#formFranquia").validate(
		{
			debug: false,
			rules: {
				nome: "required",
				datanasc: "required",
				email: {
					required: true,
					email: true
				},
				fone: "required",
				endResid: "required",
				bairro: "required",
				cidade: "required",
				uf: "required",
				cep: "required",
				cidadeFranquia: "required",
				ufFranquia: "required"
			},
			messages: {
				nome: "Obrigatório",
				datanasc: "Obrigatório",
				email: "E-mail válido obrigatório",
				fone: "Obrigatório",
				endResid: "Obrigatório",
				bairro: "Obrigatório",
				cidade: "Obrigatório",
				uf: "Obrigatório",
				cep: "Obrigatório",
				cidadeFranquia: "Obrigatório",
				ufFranquia: "Obrigatório"
			},
			submitHandler: function(form) {
				// do other stuff for a valid form
				$.post('form-franquia.php', $("#formFranquia").serialize(), function(data) {
					//$('#results').html(data);
					$('#formFranquia').html("<div style='height:"+($('#formFranquia').height()-15)+"px'></div>");
					$('#formFranquia div').html("<h3>Cadastro realizado com sucesso</h3>")
					.hide()
					.fadeIn(1500);
				});
			}
		});
		$("#formFranquia input[type='reset']").click(function(){ franquiaValidator.resetForm(); })
	}
	
	
	/*CONTATO
	========================================================================*/
	if($('body').hasClass('contato'))
	{
		
		var cadastroValidator = $("#formCadastro").validate(
		{
			debug: false,
			rules: {
				nome: "required",
				email: {
					required: true
					//email: true
				},
				fone: "required",
				endereco: "required",
				cidade: "required",
				uf: "required",
				cep: "required"
			},
			messages: {
				nome: "Obrigatório",
				email: "E-mail válido obrigatório",
				fone: "Obrigatório",
				endereco: "Obrigatório",
				cidade: "Obrigatório",
				uf: "Obrigatório",
				cep: "Obrigatório"
			},
			submitHandler: function(form) {
				// do other stuff for a valid form
				$.post('form-cadastro.php', $("#formCadastro").serialize(), function(data) {
					//$('#results').html(data);
					$('#formCadastro').html("<div style='height:"+($('#formCadastro').height()-15)+"px'></div>");
					$('#formCadastro div').html("<h3>Cadastro realizado com sucesso</h3>")
					.hide()
					.fadeIn(1500);
				});
			}
		});
		$("#formCadastro input[type='reset']").click(function(){ cadastroValidator.resetForm(); })
		
		
		var faleValidator = $("#formFaleConosco").validate(
		{
			debug: false,
			rules: {
				nome: "required",
				email: {
					required: true,
					email: true
				},
				fone: "required",
				assunto: "required",
				unidade: "required",
				mensagem: "required"
			},
			messages: {
				nome: "Obrigatório",
				email: "E-mail válido obrigatório",
				fone: "Obrigatório",
				assunto: "Obrigatório",
				unidade: "Obrigatório",
				mensagem: "Obrigatório"
			},
			submitHandler: function(form) {
				
				
				/*EDIT 05/11/12 - JQTRANSFORM + JQUERY VALIDATOR BUG - CREATE DEPENDENCY TO CUSTOM SELECT VALIDATION FUNCTION*/
				if(validateSelect()){
					
					// do other stuff for a valid form
					$.post('form-faleconosco.php', $("#formFaleConosco").serialize(), function(data) {
						//$('#results').html(data);
						$('#formFaleConosco').html("<div style='height:"+($('#formFaleConosco').height() -15)+"px'></div>");
						$('#formFaleConosco div').html("<h3>Sua mensagem foi enviada com sucesso!</h3>")
						.hide()
						.fadeIn(1500); 
					});
					
    			}
				
				
				
			}
			
		});
		$("#formFaleConosco input[type='reset']").click(function(){ faleValidator.resetForm(); })
	
	}
	
	
	/*CARDAPIO
	========================================================================*/
	if($('body').hasClass('cardapio'))
	{
		var urlVars = $.getUrlVars();
		
		switch (urlVars['prod'])
		{
			case "pizza":	
				$('body').addClass("pizza");
				$('#faixaBox h1').html("CARDÁPIO / PIZZAS");
			break;
			case "focaccia":	
				$('body').addClass("focaccia");
				$('#faixaBox h1').html("CARDÁPIO / FOCACCIAS");
			break;
			case "calzone":	
				$('body').addClass("calzone");
				$('#faixaBox h1').html("CARDÁPIO / CALZONES");
			break;
			case "lasanha":	
				$('body').addClass("lasanha");
				$('#faixaBox h1').html("CARDÁPIO / LASANHAS");
			break;
			case "salada":	
				$('body').addClass("salada");
				$('#faixaBox h1').html("CARDÁPIO / SALADAS");
			break;
			case "pizzadoce":	
				$('body').addClass("pizzadoce");
				$('#faixaBox h1').html("CARDÁPIO / PIZZAS DOCES");
			break;
			case "sobremesa":	
				$('body').addClass("sobremesa");
				$('#faixaBox h1').html("CARDÁPIO / SOBREMESAS");
			break;
			case "bebida":	
				$('body').addClass("bebida");
				$('#faixaBox h1').html("CARDÁPIO / BEBIDAS");
			break;
			case "crostino":	
				$('body').addClass("crostino");
				$('#faixaBox h1').html("CARDÁPIO / CROSTINO");
			break;
			case "vinho":	
				$('body').addClass("vinho");
				$('#faixaBox h1').html("CARDÁPIO / VINHOS");
			break;
			case "domenica":	
				$('body').addClass("domenica");
				$('#faixaBox h1').html("DOMENICA IN ITALIA");
			break;
			
			default:
				$('body').addClass("pizza");
				$('#faixaBox h1').html("CARDÁPIO / PIZZAS");
			break;
		}
		
		$('#sideBar').load('includes/include-sidebar-interno.html', function(){ configBoxes(); });
	}
	
	
	/*TIPOS DE CARDAPIO
	========================================================================*/
	carregaCardapio();
	
	
	/*CONFIG BOXES
	========================================================================*/
	configBoxes();
	
	
	/*CONFIG FORMS
	========================================================================*/
	//MARK REQUIRED FIELDS
	$('.req').each(function(){ $(this).prepend("<span class='asterisco'>* </span>"); });
	//CONFIG ALL INPUT FILE
	$('input:file').attr({'size':18}).parent().addClass('w3');
	
});

/*EDIT 05/11/12 - JQTRANSFORM + JQUERY VALIDATOR BUG - CREATE DEPENDENCY TO CUSTOM SELECT VALIDATION FUNCTION*/
function validateSelect()
{
	
	if($('#formFaleConosco .selecione select').val() == "Selecione uma unidade"){
	
		$('#formFaleConosco .selecione').after('<label for="selecione" generated="true" class="error" style="display: block; margin-top:-17px ">Obrigatório</label>');
		return false;
	}else{
		
		$('#formFaleConosco label[for="selecione"]').remove();
		return true;
	}
	
}


/*CONFIG BOXES
====================================================================================*/
function configBoxes()
{
	//WIREBOX
	$('.wireBox').each(function()
	{	
		if(!$(this).hasClass("styled"))
		{
			$(this).prepend("<div class='cornerTL'><div class='cornerTLEnd'></div></div><div class='cornerTR'><div class='cornerTREnd'></div></div>");
			var cornerW = ($(this).width() - $(this).find('h2').width())/2;
			$(this).find(".cornerTL").css({'width':cornerW-20+'px'});
			$(this).find(".cornerTR").css({'width':cornerW-20+'px'});
		
			$(this).find(".cornerTLEnd").css({'width':cornerW-20+'px'});
			$(this).find(".cornerTREnd").css({'width':cornerW-20+'px'});
			
			$(this).find('h2:eq(0)').css({'position':'absolute','width':$(this).find('h2:eq(0)').width(),'left':cornerW+'px','top':'-5px'})
			$(this).find('.container > *:first-child').css({'margin-top':'0px','padding-top':'0px'})
			$(this).addClass('styled');
		}
	});
	
	//MOLDURABOX
	$('.molduraBox').each(function()
	{
		if(!$(this).hasClass("styled"))
		{
			$(this).prepend("<div class='cornerTL'></div><div class='cornerTR'></div><div class='cornerBL'></div><div class='cornerBR'></div>");
			$(this).addClass('styled');
		}
	});
	
	//DEFAULTBOX
	$('.defaultBox .container > *:first-child').each(function()
	{
		if(!$(this).hasClass("styled"))
		{
			$(this).css({'margin-top':'0px','padding-top':'0px'});
			$(this).addClass('styled');
		}
	});
	
}





/*RESIZE
====================================================================================*/
$(window).resize(function(){ resizeMe() });
function resizeMe() {
	
	var winW, winH, root, docW, docH, hasScrollV, hasScrollH;
	
	/*Largura e altura da janela do navegador*/
	winW = $(window).width();
	winH = $(window).height();
	
	/*Largura e altura do conteúdo dependendo do navegador*/
 	if( typeof( window.innerWidth ) == 'number' ) {
		//who = "NON-IE";
		docW = $(document).width();
		docH = $(document).height();
		
		if(getInternetExplorerVersion() != -1)//se for algum IE
		{
			//alert("its IE");
			docW -= 17;	
		}
	
	} else if( document.documentElement && ( document.documentElement.clientWidth || document.documentElement.clientHeight ) ) {
		//who = "IE 6+ STANDARDS COMPLIANT MODE";
		root = document.documentElement;
		docW = root.scrollWidth;
		docH = root.scrollHeight;
	} else if( document.body && ( document.body.clientWidth || document.body.clientHeight ) ) {
		//who = "IE 4 COMPATIBLE";
		root = document.body;
		docW = root.scrollWidth;
		docH = root.scrollHeight;
	}
	
	var backgroundW = 1600;
	backgroundX = (docW - backgroundW)/2;
	
	
	/*Detect Scrollbar*/
	if(docH > winH){
		hasScrollV = true;
	}else{
		hasScrollV = false;
	}
	if(docW > winW){
		hasScrollH = true;
		
		$('#bg').css('width', '980px');
		$('#header').css('width', '980px');
		$('#content').css('width', '980px');
		$('#footer').css('width', '980px');
		$('#faixa').css('width', '980px');
		
	}else{
		hasScrollH = false;
		
		$('#bg').css('width', '100%');
		$('#header').css('width', '100%');
		$('#footer').css('width', '100%');
		$('#content').css('width', '100%');
		$('#faixa').css('width', '100%');
		
	}
	
	//TESTE
	if($('#bg').hasClass("teste"))
	{
		$('#tracebox').append("docW: "+docW+" / winW: "+winW);
	}
}





/*LOAD XML
====================================================================================*/
function loadXml(kind,who)
{
	$.ajax({
		type: "GET",
		url: who,
		dataType: "xml",
		success: function(xml)
		{
			/*UNIDADE
			----------------------------------------------------------------*/
			if(kind == "unidade")
			{
				$('#header .unidade').append("<select></select><h3></h3>");
				
				if($('body').hasClass('home'))
				$('.encontreBox .selecione').append("<select></select>");
				if($('body').hasClass('contato'))
				
				/*EDIT 05/11/12 - BUILD INDEPENDENT FROM HEADER/COOKIE SELECTION
				$('#formFaleConosco .selecione').append("<select name='unidade'></select>");
				*/
				//$('#formFaleConosco .selecione').append("<select name='unidade'><option disabled='true'>Selecione uma unidade</option></select>");
				$('#formFaleConosco .selecione').append("<select name='unidade'><option>Selecione uma unidade</option></select>");
				
				//Para cada unidade
				$(xml).find('unidade').each(function(u)
				{	
					var unNome = $(this).attr("nome");
					var unTag = $(this).attr("tag");
					var unEnd = $(this).find("endereco").text();
					var unFone = $(this).find("fone").text();
					var unInfos = $(this).find("infos");
					var unAreas = $(this).find("areas").text();
					var unPagamentos = $(this).find("pagamentos");
					var unFotos = $(this).find("fotos");
					var unMapa = $(this).find("mapa").text();
					
					//EDIT - 130712 (adicionado unFone ao option)
					$('#header select').append("<option value='"+u+"'>"+unNome+" - "+unFone+"</option>");
					
					if($('body').hasClass('home'))
					$('.encontreBox select').append("<option value='"+u+"'>"+unNome+"</option>");
					if($('body').hasClass('contato'))
					$('#formFaleConosco select').append("<option value='"+unNome+"'>"+unNome+"</option>");
					
				});
				
				//PERSONALIZAÇÃO SELECT
				$('#header .unidade').jqTransform();
				if($('body').hasClass('home'))
				$('.encontreBox .selecione').jqTransform();
				if($('body').hasClass('contato'))
				$('#formFaleConosco .selecione').jqTransform();
				
				
				
				//HEADER SELECT CLICK - Capturing the change event of the Transformed Select Box using the modified method of capturing the value change event.
				var selectedIndex;
				$("#header div.jqTransformSelectWrapper ul li a").click(function(event)
				{
					selectedIndex = $(this).parent().index( this[0]  );
					unidadeClick(selectedIndex,$(xml));
				});
				$(".encontreBox div.jqTransformSelectWrapper ul li a").click(function(event)
				{
					selectedIndex = $(this).parent().index( this[0]  );
					unidadeClick(selectedIndex,$(xml));
				});
				
				
				//DISPARA O PRIMEIRO CLIQUE AUTOMATICAMENTE
				if($.cookie('baggio-unidade') == null)
				{
					$("#header div.jqTransformSelectWrapper ul li:eq(0) a").trigger('click');
				}
				else
				{
					$("#header div.jqTransformSelectWrapper ul li:eq("+$.cookie('baggio-unidade')+") a").trigger('click');
				}
				
			}
			
			
			/*CARDAPIO
			----------------------------------------------------------------*/
			else if($('body').hasClass('cardapio'))
			{
				//CLEANS CONTENT
				$('#contentBox').children().not('#sideBar').remove();
				
				//CREATE CARDAPIO ARRAY
				cardapioModalArray = new Array();
				
				//DEFINE NOME GERAL FOR MODAL H1
				var nomeProdutoGeral;
				if($('body').hasClass('pizza')) {nomeProdutoGeral = "Pizza"}
				if($('body').hasClass('focaccia')) {nomeProdutoGeral = "Focaccia"}
				if($('body').hasClass('pizzadoce')) {nomeProdutoGeral = "Pizza Doce"}
				
				if($('body').hasClass('domenica'))
				{
					$('#contentBox').append(	"<p style='width:500px'>Além das delícias do cardápio tradicional, a Baggio Pizzeria & Focacceria oferece a seus clientes o Menu Domenica In'Itália, servido apenas nos domingos à noite. O cardápio especial traz receitas italianíssimas e ingredientes selecionados, típicos do país das massas.</p><br/>"+
												"<p style='width:500px'>O Menu Domenica In'Itália está disponível para consumo nas unidades da rede em Curitiba, nos bairros Água Verde, Champagnat, Jardim das Américas e Juvevê, como também em Santa Catarina, na unidade de Blumenau. O cardápio tradicional é servido normalmente.</p><br/>"+
												"<p>** Este cardápio não está disponível para Delivery</p><br/><br/>");
				}
				
				
				//BUILDS CARDAPIOS
				$(xml).find('categoria').each(function(i)
				{
					var catTitulo = $(this).attr("titulo");
					var catTituloSing = $(this).attr("tituloSing");
					var catClasse = $(this).attr("classe");
					var catImagem = $(this).attr("imagem");
					
					//CARDAPIO BOX
					$('#contentBox').append(
					"<div id='cardapio"+i+"' class='cardapioBox'>"+
						"<h2 class='"+catClasse+"'>"+catTitulo+"</h2>"+
						"<img src='imgs/"+catImagem+"' width='260' height='260' border='0' alt=''/>"+
						"<div class='cardapioList scroll-pane'>"+
							"<div class='cardapioListContainer'>"+
								"<ul></ul>"+
							"</div>"+
						"</div>"+
					"</div>");
					
					//BUILD EACH ITEM
					var catItem = $(this).find('item').each(function(j)
					{
						var itemTitulo = $(this).attr("titulo");
						var itemTituloSing = $(this).attr("tituloSing");//utilizado no cardapio de bebidas
						var itemTxt1 = $(this).find("txt1").text();
						var itemTxt2 = $(this).find("txt2").text();
						var unidades = $(this).find('unidades');
						//var fblike = "<fb:like href='"+$(this).find('fblike').text()+"' send='false' layout='button_count' width='150' show_faces='false'></fb:like>";
						var fblike = "";
						
						//BOTÃO ADICIONAR AO PEDIDO / MONTAR
						var botao;
						if($('body').hasClass('pizza'))
						{
							//botao = "<a class='botMontar btnRed'>Monte sua pizza</a>";
							botao = "";
						}
						else if($('body').hasClass('focaccia'))
						{
							//botao = "<a class='botMontar btnRed'>Monte sua focaccia</a>";
							botao = "";
						}
						else if($('body').hasClass('pizzadoce'))
						{
							//botao = "<a class='botMontar btnRed'>Monte sua pizza doce</a>";
							botao = "";
						}
						else if($('body').hasClass('domenica'))
						{
							botao = "";
						}
						else if($('body').hasClass('sobremesa'))
						{
							botao = "";
						}
						else if($('body').hasClass('bebida') && itemTitulo == "Vinhos")
						{
							botao = "";
						}
						else
						{
							//botao = "<a class='botAdicione btnRed'>Adicionar ao pedido</a>";
							botao = "";
						}
						
						//BOTÃO LIKE
						var botLike;
						if( $('body').hasClass('pizza') || $('body').hasClass('focaccia') || $('body').hasClass('lasanha') || $('body').hasClass('calzone') || $('body').hasClass('salada') || $('body').hasClass('pizzadoce'))
						{
							botLike = "<span class='botLike'></span>";
							
						}else{
							botLike = ""
						}
						
						
						if( !$('body').hasClass('sobremesa'))
						{
							/*RETIRAR DEPENDENCIA DA UNIDADE NO XML* /
							for( var u=0; u < unidades.children().size(); u++)
							{
								
								//Se o item contem tag da unidade selecionada, adicione o item
								var unidade = unidades.find('unidade:eq('+u+')').text();
								if ($.cookie('baggio-tag').indexOf(unidade) != -1)
								{
									/**/
									$('#cardapio'+i+' ul').append(
									"<li>"+
										"<a class='link' name='"+itemTituloSing+"'>"+itemTitulo+"</a>"+
										"<div class='infoBox'>"+
											"<p>"+itemTxt1+"</p>"+
											"<p class='desc'>"+itemTxt2+"</p>"+
											botLike+
											botao+
										"</div>"+
									"</li>");
									
									$('#cardapio'+i+' ul li:eq('+j+') .infoBox .botLike').html(fblike);
									//$('#cardapio'+i+' ul li:eq('+j+') .infoBox .botLike').data("likeInfo",fblike);
									
							/*FIM -RETIRAR DEPENDENCIA DA UNIDADE NO XML* /
								}
							}
							/**/
						}
						else
						{
							$('#cardapio'+i+' .cardapioList').html("<img src='imgs/consultenossasdeliciosasopcoes.png' width='330' height='160' border='0' alt='Consulte nossas deliciosas opções!' style='margin:-20px 0px 0px 20px'/>");
						}
						
						
					});
					
					$("#cardapio"+i+" h2").prepend("<span class='titleDecoLGreen'></span>").append("<span class='titleDecoRGreen'></span>");
					
					//CLICK EVENTS
					$("#cardapio"+i+" a.link").click(function(){ animaCardapio($(this),"#cardapio"+i); });
					
					$("#cardapio"+i+" .botMontar").click(function()
					{
						var indiceCategoria = i;
						var indiceProduto = $("#cardapio"+i).data("cO");
						var nomeProduto = $("#cardapio"+i+" li:eq("+indiceProduto+") a.link").text();
						
						abreModal(nomeProdutoGeral,indiceCategoria,indiceProduto,nomeProduto,800,640);
					});
					
					$("#cardapio"+i+" .botAdicione").click(function()
					{
						var categoriaProd = i;
						var qualProd = $("#cardapio"+i).data("cO");
						
						var nomeProd;
						if(catTituloSing == "Cerveja" || catTituloSing == "Espumante e Frisante" || catTituloSing == "Sobremesa")
						{
							nomeProd = $("#cardapio"+i+" li:eq("+qualProd+") a.link").text();
						}
						else if(catTituloSing == "Bebida")
						{
							nomeProd = $("#cardapio"+i+" li:eq("+qualProd+") a.link").attr("name");
						}
						else
						{
							nomeProd = catTituloSing + " "+ $("#cardapio"+i+" li:eq("+qualProd+") a.link").text();	
						}
						
						
						var descProd = 	"<ul class='desc'>"+
											"<li>"+$("#cardapio"+i+" li:eq("+qualProd+") p:eq(0)").html();+"</li>"+
											"<li>"+$("#cardapio"+i+" li:eq("+qualProd+") p:eq(1)").html();+"</li>"+
										"</ul>";
										
						pedidoInsert(nomeProd,descProd);
					});
					
					//COPY HTML FOR MODALS -- BEFORE -- INITIALIZING JSCROLLPANE	
					cardapioModalArray.push( $("#cardapio"+i).html() );
				});
				
				//$(".cardapioBox h2'").prepend("<div class='titleDecoLGreen'></div>").append("<div class='titleDecoRGreen'></div>");
				
				//INITIALIZE JSCROLLPANE
				$('.scroll-pane').jScrollPane({ animateScroll:true, verticalGutter:0 });
				
			}
			
			
			/*NOVIDADES
			----------------------------------------------------------------*/
			else if(kind == "novidades")
			{
				var noticiaID;
				var noticiaData;
				var noticiaTitulo;
				var noticiaTexto;
				var noticiaFotos;
				var noticiaFotosList = "";
				var urlVars = $.getUrlVars();
				
				
				if($('body').hasClass('home'))
				{
					novidadesMontaListaHome($(xml));
				}
				
				//LISTA
				if($('body').hasClass('novidades') && urlVars['id'] == undefined )
				{
					novidadesMontaLista($(xml));
				}
				
				else if($('body').hasClass('novidades') && urlVars['id'] != undefined )
				{
					var noticia = $(xml).find("noticica[id='"+urlVars['id']+"']");
					
					//se não encontrar a id, direcionar para LISTA
					if(noticia.size() == 0)
					{
						//novidadesMontaLista();
						window.location = "novidades.html";
					}
					else
					{
						$('body').addClass("leitura");
						$('#contentBox .defaultBox').addClass('novidadesLeitura');
						$('.novidadesLeitura h2').prepend("<span class='titleDecoLGreen'></span>").append("<span class='titleDecoRGreen'></span>");
						
						noticiaID = noticia.attr("id");
						noticiaData = noticia.attr("date");
						noticiaTitulo = noticia.find("titulo").text();
						noticiaTexto = noticia.find("texto").text();
						noticiaFotos = noticia.find("fotos")
						
						//MONTA FOTOS
						var navPgArray = new Array();
						if(noticiaFotos.children().size() > 0)
						{
							noticiaFotosList +=	"<div class='fotos'>"+
													"<div class='nav'></div>"+
													"<div class='carouselContainer'>"+
														"<ul>";
							
							var navString = "<div class='nav'>";
							var pgStr = "";
							for(var nf = 0; nf < noticiaFotos.children().size(); nf++)
							{
								var noticiaFoto = noticiaFotos.find('foto:eq('+nf+')').text();
								noticiaFotosList += "<li><img src='arquivos/"+noticiaFoto+"' border='0' alt=''/></li>";
								
								//NAV
								if(noticiaFotos.children().size() > 1)
								{
									var navStringInsertIndex = noticiaFotosList.indexOf("<div class='nav'>");
									pgStr = String("<div class='pg "+(nf+1)+"'></div>");
									noticiaFotosList = noticiaFotosList.substr(0,navStringInsertIndex+navString.length) +pgStr+ noticiaFotosList.substr(navStringInsertIndex+navString.length);
									navString += pgStr;
									
									navPgArray.push(".fotos .nav ."+(nf+1));
								}
							}
							noticiaFotosList +=			"</ul>"+
													"</div>"+
												"</div>";
							
						}
						
						
						
						//WRITE HTML
						$('.container')
						.html(	"<h3>"+noticiaTitulo+"</h3>"+
								"<br/>"+
								//"<span>"+noticiaData+"</span>"+
								noticiaFotosList+
								noticiaTexto);
						
						
						var imgMaxW = 0;
						var imgMaxH = 0;
						
						//AJUSTA TAMANHO DAS FOTOS
						$(".fotos .carouselContainer ul li img").each(function()
						{
							$(this).load(function()
							{
								var imgW = this.width;
								var imgH = this.height;
								
								
								if(imgW >= imgH)
								{
									$(this).width(350)	
								}
								else
								{
									$(this).height(400)
								}
								
								if(this.width > imgMaxW)
								{
									imgMaxW = this.width;
								}
								if(this.height > imgMaxH)
								{
									imgMaxH = this.height
								}
								
								$(".fotos, .fotos .carouselContainer, .fotos .carouselContainer ul li").css({"width":imgMaxW,"height":imgMaxH})
								
							});
							
							
						});
						
						//JCAROUSEL
						if(noticiaFotos.children().size() > 1)
						{
							$("#contentBox .carouselContainer").jCarouselLite({speed:250,visible:1,circular:true,btnGo: navPgArray});
							$(".nav .pg").click(function(){ $(this).addClass("selected").siblings().removeClass("selected")});
							$(".nav .1").trigger("click");
							$('.nav').css({"left": ( $(".fotos").width() - $(".nav").width())/2+"px"});
						}
					}
				}
				
				
			}
			
		}
		
		
	});
}


/*NOVIDADES
====================================================================================*/	
function novidadesMontaLista(_myXml)
{
	$('body').addClass("lista");
	$('#contentBox .defaultBox').addClass('novidadesLista');
	$('.novidadesLista h2').prepend("<span class='titleDecoLGreen'></span>").append("<span class='titleDecoRGreen'></span>");
	
	$('.container').html("<ul></ul>");
	
	_myXml.find('noticica').each(function(n)
	{
		noticiaID = $(this).attr("id");
		noticiaData = $(this).attr("date");
		noticiaTitulo = $(this).find("titulo").text();
		noticiaTexto = $(this).find("texto").text();
		noticiaFotos = $(this).find("fotos")
		
		$('.container ul')
		.append(	"<li>"+
						"<a href='novidades.html?id="+noticiaID+"'>"+
							"<span>"+noticiaData+"</span>"+
							noticiaTitulo+
						"</a>"+
					"</li>");
		
	});	
}
function novidadesMontaListaHome(_myXml)
{
	$('#novidades').append("<ul></ul>");
	
	var not1 = _myXml.find('noticica:eq(0)');
	$('#novidades ul').append("<li><a href='novidades.html?id="+not1.attr("id")+"'>"+not1.find("titulo").text()+"</a></li>");
	
	var not2 = _myXml.find('noticica:eq(1)');
	$('#novidades ul').append("<li><a href='novidades.html?id="+not2.attr("id")+"'>"+not2.find("titulo").text()+"</a></li>");
}




/*UNIDADE CLICK
====================================================================================*/
function unidadeClick(_index,_xml)
{
	//VARS
	var selectedUnidade = _xml.find("unidade:eq("+_index+")");
	var selectedNome = selectedUnidade.attr("nome");
	var selectedTag = selectedUnidade.attr("tag");
	var selectedLink = selectedUnidade.attr("link");
	var selectedEndereco = selectedUnidade.find("endereco").text();
	var selectedFone = selectedUnidade.find("fone").text();
	var selectedInfos = selectedUnidade.find("infos");
	var selectedAreas = selectedUnidade.find("areas").text();
	var selectedPagamentos = selectedUnidade.find("pagamentos");
	var selectedFotos = selectedUnidade.find("fotos");
	var selectedFoto = selectedUnidade.find("foto:eq(0)").text();
	var selectedMapa = selectedUnidade.find("mapa").text();
	
	//SAVE TO COOKIES
	$.cookie('baggio-unidade', _index);
	$.cookie('baggio-tag', selectedTag);
	//$('#tracebox').prepend($.cookie('baggio-unidade')+'<br/>');
	
	//UPDATE DATA
	//EDIT - 130712 (comentado)
	//$('#header .unidade h3').html("<b>Delivery: "+selectedFone+" </b>"+selectedInfos.find("info:eq(0)").text());
	
	if($('body').hasClass('home'))
	{
		//SYNC CLICK
		$("#header div.jqTransformSelectWrapper ul li a.selected").removeClass('selected');
		$("#header div.jqTransformSelectWrapper ul li:eq("+_index+") a").addClass('selected');
		//EDIT - 130712 (adicionado selectedFone ao texto)
		$("#header div.jqTransformSelectWrapper span").text(selectedNome+" - "+selectedFone)
		
		$(".encontreBox div.jqTransformSelectWrapper ul li a.selected").removeClass('selected');
		$(".encontreBox div.jqTransformSelectWrapper ul li:eq("+_index+") a").addClass('selected');
		$(".encontreBox div.jqTransformSelectWrapper span").text(selectedNome)

		//UPDATE DATA
		$('.encontreBox .encontreFoto').html("<a href='"+selectedLink+"'><img src='arquivos/"+selectedFoto+"' alt=''/></a>");
		$('.encontreBox .endereco').html(selectedEndereco+"<br/>Telefone: "+selectedFone+"<br/>");
		
		var encontreInfos = "";
		for(var i = 0; i < selectedInfos.find("info").size(); i++)
		{
			encontreInfos += selectedInfos.find("info:eq("+i+")").text()+"<br/>"
		}
		$('.encontreBox .desc').html(encontreInfos);
		$('.encontreBox .encontreMap').html(selectedMapa);
	}
	
	if($('body').hasClass('contato'))
	{
		//NOME
		$('.contatoInfo h3').html(selectedNome);
		
		//ENDERECO
		$('.contatoInfo .endereco').html(selectedEndereco+"<br/>Telefone: "+selectedFone+"<br/>");
		
		//INFOS
		var contatoInfos = "";
		for(var j = 0; j < selectedInfos.find("info").size(); j++)
		{
			contatoInfos += selectedInfos.find("info:eq("+j+")").text()+" "
		}
		$('.contatoInfo .desc').html(contatoInfos);
		$('.contatoInfo .areas').html(selectedAreas);
		
		//PAGAMENTO
		$('.contatoInfo .pagamento').remove();
		$('.contatoInfo > .container').append("<ul class='pagamento'></ul>")
		var contatoPags = "";
		for(var k = 0; k < selectedPagamentos.find("pag").size(); k++)
		{
			$('.contatoInfo .pagamento').append('<li>'+selectedPagamentos.find("pag:eq("+k+")").text()+'</li>');
		}
		//LEGENDA
		$('.contatoInfo .legenda').remove();
		$('.contatoInfo > .container').append("<p class='legenda'><br/><br/><span class='asterisco'>*</span> Parcialmente&nbsp;&nbsp;&nbsp;<span class='asterisco'>*</span><span class='asterisco'>*</span> Somente na unidade</p>");
		
		
		//FOTOS
		$(".contatoFotos .carouselContainer ul").remove();
		$(".contatoFotos .carouselContainer").append("<ul></ul>");
		
		for( var f = 0; f < selectedFotos.children().size(); f++ )
		{
			$(".contatoFotos .carouselContainer ul").append('<li><a href="lala"><img src="arquivos/'+selectedFotos.find('foto:eq('+f+')').text()+'" width="420" height="220"/></a></li>');
		}
		
		if(selectedFotos.children().size() > 1)
		{ $(".contatoFotos .carouselContainer").jCarouselLite({ auto: 10000, speed: 750, visible: 1 }); }
		else
		{ $(".contatoFotos .carouselContainer").jCarouselLite({ visible: 1 }); }
		
		//MAPA
		$(".contatoMapa .molduraContainer").html(selectedMapa);
		configBoxes();
		
		
		/*EDIT 05/11/12 - DEACTIVATE AUTO SELECTION
		//FORM FALE CONOSCO
		$("#formFaleConosco div.jqTransformSelectWrapper ul li a.selected").removeClass('selected');
		$("#formFaleConosco div.jqTransformSelectWrapper ul li:eq("+_index+") a").addClass('selected');
		$("#formFaleConosco div.jqTransformSelectWrapper span").text(selectedNome)
		*/
	}
	
	
	
	//UPDATE CARDAPIOS
	carregaCardapio();
	
}





/*CARREGA CARDAPIO (XML)
====================================================================================*/
function carregaCardapio()
{
	if($('body').hasClass('pizza'))
	{
		loadXml("cardapio","xml/pizzas.xml");
	}
	else if($('body').hasClass('focaccia'))
	{
		loadXml("cardapio","xml/focaccias.xml");
	}
	else if($('body').hasClass('calzone'))
	{
		loadXml("cardapio","xml/calzones.xml");
	}
	else if($('body').hasClass('lasanha'))
	{
		loadXml("cardapio","xml/lasanhas.xml");
	}
	else if($('body').hasClass('salada'))
	{
		loadXml("cardapio","xml/saladas.xml");
	}
	else if($('body').hasClass('pizzadoce'))
	{
		loadXml("cardapio","xml/pizzasdoces.xml");
	}
	else if($('body').hasClass('sobremesa'))
	{
		loadXml("cardapio","xml/sobremesas.xml");
	}
	else if($('body').hasClass('bebida'))
	{
		loadXml("cardapio","xml/bebidas.xml");
	}
	else if($('body').hasClass('crostino'))
	{
		loadXml("cardapio","xml/crostino.xml");
	}
	else if($('body').hasClass('vinho'))
	{
		loadXml("cardapio","xml/vinhos.xml");
	}
	else if($('body').hasClass('domenica'))
	{
		loadXml("cardapio","xml/domenica.xml");
	}
}





/*ANIMA CARDAPIO
====================================================================================*/
function animaCardapio(_this,meuCardapio)
{
	//VARS
	var myContainer;
	var myUl;
	var myLi;
	var myDiv;
	var myFbButton;
	var myA;
	var myIndex;
	var liLength;
	var myOffset;
	var openLi;
	var prevLi;
	var api;
	
	var currentOpen = $(meuCardapio).data("cO");
	
	//IDENTIFICA
	myContainer = _this.parent().parent().parent();
	myUl = _this.parent().parent();
	myLi = _this.parent();
	myDiv = _this.siblings('div');
	myFbButton = myDiv.find('span')
	myA = _this;
	myIndex = $(meuCardapio+" li").index( myLi[0] );
	liLength = myUl.children().size();
	
	//ATUALIZA ALTURA DE CONTAINER
	$(meuCardapio+" .cardapioListContainer").css({'height':44*liLength + 132});

	//FECHADO
	if(myA.hasClass('selected') == false)
	{
		//DESATIVA ANTERIOR
		if(currentOpen !== undefined)
		{
			openLi = $(meuCardapio+" li:nth-child("+(currentOpen +1)+")");
			openLi.children('a').removeClass('selected');
			openLi.children('div').stop().animate({'height':'0px'},250,function()
			{
				openLi.children('div').css({'display':'none'})	
				//REINITIALISE SCROLL PANE
				$(meuCardapio+' .scroll-pane').jScrollPane({ animateScroll: true, verticalGutter:0 });
				api = $(meuCardapio+' .scroll-pane').data('jsp');
			});
		}
		
		//ATIVA ATUAL
		myDiv.css({'display':'block'}).stop().animate({'height':'132px'},250,function()
		{
			//ADD CLASS
			myA.addClass('selected');
			
			//INSERT FB BUTTON
			//myFbButton.html( myFbButton.data("likeInfo") );
			
			
			//REINITIALISE SCROLL PANE
			if(myIndex <= 1)
			{
				$(meuCardapio+' .scroll-pane').jScrollPane({ animateScroll: true, verticalGutter:0 });
				api = $(meuCardapio+' .scroll-pane').data('jsp');
				//api.scrollToElement(prevLi, true); //Por algum motivo o scrollToElement não está indo para o primeiro li
				api.scrollToY(0, true);
			}else
			{
				prevLi = $(meuCardapio+" li:nth-child("+myIndex+")");
				$(meuCardapio+' .scroll-pane').jScrollPane({ animateScroll: true, verticalGutter:0 });
				api = $(meuCardapio+' .scroll-pane').data('jsp');
				api.scrollToElement(prevLi, true);
				
			}
			
			//ASSIGN NEW CURRENT OPEN
			$(meuCardapio).data("cO",myIndex);
		});		
	}
	//ABERTO
	else
	{
		//DESATIVA
		myDiv.stop().animate({'height':'0px'},250, function()
		{
			myDiv.css({'display':'none'})
			
			//REMOVE CLASS
			myA.removeClass('selected');
			
			//REINITIALISE SCROLL PANE
			if(myIndex <= 1)
			{
				$(meuCardapio+' .scroll-pane').jScrollPane({ animateScroll: true, verticalGutter:0 });
				api = $(meuCardapio+' .scroll-pane').data('jsp');
				//api.scrollToElement(prevLi, true); //Por algum motivo o scrollToElement não está indo para o primeiro li
				api.scrollToY(0, true);
			}else
			{
				if(myIndex < liLength-5)
				{
					prevLi = $(meuCardapio+" li:nth-child("+myIndex+")");
					$(meuCardapio+' .scroll-pane').jScrollPane({ animateScroll: true, verticalGutter:0 });
					api = $(meuCardapio+' .scroll-pane').data('jsp');
					api.scrollToElement(prevLi, true);
				}
				else
				{
					$(meuCardapio+' .scroll-pane').jScrollPane({ animateScroll: true, verticalGutter:0 });
					api = $(meuCardapio+' .scroll-pane').data('jsp');
					api.scrollToY((44*liLength - (6*44)), true);
				}
			}
			$(meuCardapio+' .scroll-pane').jScrollPane({ animateScroll: true, verticalGutter:0 });
			api = $(meuCardapio+' .scroll-pane').data('jsp');
		});	
	}
}





/*MODAL
====================================================================================*/
function abreModal(_nomeGeral,_indiceCategoria,_indiceProduto,_nomeProduto,myWidth,myHeight)
{
	//BASIC CONFIG
	windowScrollTop = $(window).scrollTop();
	
	if($('html').hasClass('ie7')){
		$('html').css("overflow","hidden");
	}else{
		$('body').css("overflow","hidden");
	}
	
	$('body').append(
	"<div class='modal'>"+
		"<div class='modalBg'></div>"+
		"<div class='modalBox' style='width:"+myWidth+"px;height:"+myHeight+"px;margin:"+Number(-myHeight*.5)+"px 0px 0px "+Number(-myWidth*.5)+"px'>"+
			"<div class='botfecharModal'></div>"+
			"<div class='modalBoxContainer scroll-pane' style='width:"+Number(myWidth)+"px;height:"+Number(myHeight)+"px'>"+
				"<div class='modalBoxContent' style='width:"+Number(myWidth-11)+"px'></div>"+
			"</div>"+
		"</div>"+
		"</div>");
	$('.modal').css({"top":windowScrollTop});
	
	/*BOT FECHAR*/
	$('.botfecharModal').click(function()
	{
		fechaModal();
	});
	
	/*ESC KEY PRESS LISTENER*/
	$(document).keyup(function(e)
	{
		if (e.keyCode == 27) { fechaModal() }   // esc
	});
	
	/*SCROLL-PANE*/
	$('.modal .scroll-pane').jScrollPane();
	
	//MONTA MODAL
	$('.modalBoxContainer').load("modal-monte.html", function()
	{
		//AJUSTA TÍTULO DE ACORDO COM O PRODUTO
		$('#headerModal h1').html("Monte sua "+_nomeGeral);
		
		//ABRE LISTA DAS ABAS DOS CARDÁPIOS
		$('#cardapioModal').html("<ul class='abasModal'></ul>");
		
		for(var m = 0; m < cardapioModalArray.length; m++)
		{
			var tabName = '#tabs-'+(m+1);
			
			//BUILD TABS STRUCTURE
			$("#cardapioModal .abasModal").append("<li><a href='"+tabName+"'></a></li>");
			$("#cardapioModal").append("<div id='tabs-"+(m+1)+"' class='abaBox'></div>");
			
			//INSERT CARDAPIOS HTMLS
			$(tabName).html("<div class='cardapioBox' style='height:260px; margin-left:45px'></div>");
			$(tabName+' div').append(cardapioModalArray[m]);
			
			//INSERT TABS NAMES
			var catName = $(tabName+' .cardapioBox h2').text();
			$("#cardapioModal .abasModal li:eq("+m+") a").append(catName);
			$(tabName+' .cardapioBox h2').remove();
			
			$(tabName+' .cardapioBox').css({'position':'absolute','top':'0px'});
			$(tabName+' .cardapioBox img, #tabs-'+(m+1)+' .cardapioBox .cardapioList').css({'top':'0px'});
			$(tabName+' .cardapioBox .botMontar').html('Adicionar Sabor').removeClass('btnGreen').addClass('btnRed').click(function(){ modalAddSabor( $(this).parent().parent().find('.link').text() ) });
		}
		
		//CLICK FUNCTIONS
		$("#cardapioModal .cardapioBox a.link").each(function()
		{	
			var myTab = "#"+$(this).parent().parent().parent().parent().parent().parent().attr("id");
			$(this).click(function() { animaCardapio(	$(this), myTab) });
		});
		
		//INITIALIZE JSCROLLPANE
		$('.scroll-pane').jScrollPane({ animateScroll:true, verticalGutter:0 });
		
		//configModal(_indiceCategoria,_indiceProduto,_nomeProduto);
		configModal(_indiceCategoria,_nomeProduto);
	});
}
function fechaModal()
{
	$('.modal').remove();
	if($('html').hasClass('ie7'))
	{	
		$('html').css("overflow","auto");
	}else{
		$('body').css("overflow","auto");
	}
}


//MODAL VARS
var modalTamanho;
var modalTamanhoArray;
var modalQtdeSabores;
var modalSaboresArray;
var modalOpcionaisArray;


function configModal(_indiceCategoria,_nomeProduto)
{
	//INICIA COM ABA CORRESPONDENTE
	$( "#cardapioModal" ).tabs({ selected: _indiceCategoria });
	
	modalOpcionaisArray = new Array();
	
	
	//ESTRUTURA TABELA
	if($('body').hasClass("pizza"))
	{
		modalTamanhoArray = ["Brotinho","Média","Grande","Gigante"];
		
		$('#seuProduto').addClass("pizza");
	
		$('#monteProduto td:eq(0)')
		.html(	"<ul class='tamanhos'>"+
					"<li class='op1'>Brotinho</li>"+
					"<li class='op2'>Média</li>"+
					"<li class='op3'>Grande</li>"+
					"<li class='op4'>Gigante</li>"+
				"</ul>"+
				"<div class='sliderTamanhos'></div>");
				
		$('#monteProduto td:eq(1)')
		.html(	"<ul class='sabores'>"+
					"<li class='op1'>1</li>"+
				"</ul>"+
				"<ul class='sabores'>"+
					"<li class='op1'>1</li>"+
					"<li class='op3'>2</li>"+
				"</ul>"+
				"<ul class='sabores'>"+
					"<li class='op1'>1</li>"+
					"<li class='op2'>2</li>"+
					"<li class='op3'>3</li>"+
				"</ul>"+
				"<div class='sliderSabores'></div>");
				
		//CHECKBOX E RADIOS WITHOUT LABEL TEXT - BUG ON JQTRANSFORM
		$('#monteProduto td:eq(2)')
		.html(	"<div class='optional'><label><input type='checkbox' name='opcionais' value='Massa Integral' /></label><span class='outsideLabel'>Massa Integral</span></div>"+
				"<div class='optional'><label><input type='checkbox' name='opcionais' value='Molho Parmeggiana' /></label><span class='outsideLabel'>Molho Parmeggiana</span></div>"+
				"<div class='optional'><label><input type='checkbox' name='opcionais' value='Cebola Crocante' /></label><span class='outsideLabel'>Cebola Crocante</span></div>"+
				"<div class='optional'><label><input type='checkbox' name='opcionais' value='Mussarela de Búfala' /></label><span class='outsideLabel'>Mussarela de Búfala</span></div>"+
				"<div class='optional' style='display:none'><label><input type='checkbox' name='opcionais' value='Borda Recheada Catupiry' /></label><span class='outsideLabel'>Borda Recheada Catupiry</span></div>"+
				"<div class='optional' style='display:none'><label><input type='checkbox' name='opcionais' value='Borda Recheada Cheddar' /></label><span class='outsideLabel'>Borda Recheada Cheddar</span></div>");
		
		//OPCIONAIS
		$('.optional input').click(function()
		{
			var myValue = $(this).attr("value");
			var myIndex;
			
			if(!$(this).attr("checked"))//se estiver desmarcado
			{
				if(myValue == "Borda Recheada Cheddar")
				{
					$("#monteProduto input:checkbox[value='Borda Recheada Catupiry']").attr("checked",false);
					$("#monteProduto input:checkbox[value='Borda Recheada Catupiry']").siblings("a").removeClass("jqTransformChecked");
					
					myIndex = modalOpcionaisArray.indexOf('Borda Recheada Catupiry');
					if(myIndex >=0){ modalOpcionaisArray.splice(myIndex,1); }
					
				}
				if(myValue == "Borda Recheada Catupiry")
				{
					$("#monteProduto input:checkbox[value='Borda Recheada Cheddar']").attr("checked",false);
					$("#monteProduto input:checkbox[value='Borda Recheada Cheddar']").siblings("a").removeClass("jqTransformChecked");
					
					myIndex = modalOpcionaisArray.indexOf('Borda Recheada Cheddar');
					if(myIndex >=0){ modalOpcionaisArray.splice(myIndex,1); }
				}

				if(modalOpcionaisArray.indexOf(myValue) == -1)
				{
					modalOpcionaisArray.push(myValue);
				}
				
			}
			else
			{
				var myIndex = modalOpcionaisArray.indexOf(myValue);
				modalOpcionaisArray.splice(myIndex,1);
			}
		})

		$('#monteProduto .obs').html("OBS: Pizzas gigantes deverão ser retiradas no balcão.");
	}
	
	else if($('body').hasClass("pizzadoce"))
	{
		modalTamanhoArray = ["Brotinho","Média","Grande","Gigante"];
		
		$('#seuProduto').addClass("pizza");
		
		$('#monteProduto td:eq(0)')
		.html(	"<ul class='tamanhos'>"+
					"<li class='op1'>Brotinho</li>"+
					"<li class='op2'>Média</li>"+
					"<li class='op3'>Grande</li>"+
					"<li class='op4'>Gigante</li>"+
				"</ul>"+
				"<div class='sliderTamanhos'></div>");
				
		$('#monteProduto td:eq(1)')
		.html(	"<ul class='sabores'>"+
					"<li class='op1'>1</li>"+
				"</ul>"+
				"<ul class='sabores'>"+
					"<li class='op1'>1</li>"+
					"<li class='op3'>2</li>"+
				"</ul>"+
				"<ul class='sabores'>"+
					"<li class='op1'>1</li>"+
					"<li class='op2'>2</li>"+
					"<li class='op3'>3</li>"+
				"</ul>"+
				"<div class='sliderSabores'></div>");
				
		$('#monteProduto td:eq(2)')
		.html(	"<div class='optional'><label><input type='checkbox' name='opcionais' value='Massa Integral' /></label><span class='outsideLabel'>Massa Integral</span></div>"+
				"<div class='optional' style='display:none'><label><input type='checkbox' name='opcionais' value='Borda Recheada Chocolate' /></label><span class='outsideLabel'>Borda Recheada Chocolate</span></div>");
		
		$('.optional input').click(function()
		{
			var myValue = $(this).attr("value");
			var myIndex;
			
			if(!$(this).attr("checked"))
			{
				if(modalOpcionaisArray.indexOf(myValue) == -1)
				{
					modalOpcionaisArray.push(myValue);
				}
			}
			else
			{
				var myIndex = modalOpcionaisArray.indexOf(myValue);
				modalOpcionaisArray.splice(myIndex,1);
			}
		})
				
		$('#monteProduto .obs').html("OBS: Pizzas gigantes deverão ser retiradas no balcão.");
	}
	
	else if($('body').hasClass("focaccia"))
	{
		modalTamanhoArray = ["Média","Grande"];
		
		$('#seuProduto').addClass("focaccia");
		
		$('#monteProduto td:eq(0)')
		.html(	"<ul class='tamanhos'>"+
					"<li class='op1'>Média</li>"+
					"<li class='op4'>Grande</li>"+
				"</ul>"+
				"<div class='sliderTamanhos'></div>");
				
		$('#monteProduto td:eq(1)')
		.html(	"<ul class='sabores'>"+
					"<li class='op1'>1</li>"+
				"</ul>"+
				"<ul class='sabores'>"+
					"<li class='op1'>1</li>"+
					"<li class='op3'>2</li>"+
				"</ul>"+
				"<div class='sliderSabores'></div>");
				
		$('#monteProduto tr:eq(2)').css({"display":"none"})
		$('#monteProduto table').css({"margin-top":"50px"})
		$('#monteProduto .obs').html("OBS: O sabor N²3-Itália não poderá ser dividido com outro sabor");
	}
	
	
	//VARS INICIAIS
	modalTamanho = modalTamanhoArray[0];
	modalQtdeSabores = 1;
	
	
	//CONFIG INICIAL SLIDER SABORES - PRECISA INICIALIZAR ANTES DO SLIDER TAMANHO
	var qtdeSaboresInicial;
	if($('body').hasClass("pizza") || $('body').hasClass("pizzadoce"))
	{
		qtdeSaboresInicial = 1;
		$('#monteProduto .sabores:eq(0)').css({"display":"block"});
		$('#monteProduto .sabores:eq(1)').css({"display":"none"});
		$('#monteProduto .sabores:eq(2)').css({"display":"none"});
	}
	else if($('body').hasClass("focaccia"))
	{
		qtdeSaboresInicial = 2
		$('#monteProduto .sabores:eq(0)').css({"display":"none"});
		$('#monteProduto .sabores:eq(1)').css({"display":"block"});
		$('#monteProduto .sabores:eq(2)').css({"display":"none"});
	}
	$('.sliderSabores').slider({ range: 'max', min: 1, max: qtdeSaboresInicial, value: 1, change: function(event,ui)
	{
		$('#seuProduto .aviso').css({'display':'none'})
		modalQtdeSabores = ui.value;
		if(ui.value == 1)
		{
			$('#seuProduto').removeClass('doisSabores tresSabores').addClass('umSabor');
			modalRemoveSabor($('#seuProduto .box3'));
			modalRemoveSabor($('#seuProduto .box2'));
		}
		else if(ui.value == 2)
		{
			$('#seuProduto').removeClass('umSabor tresSabores').addClass('doisSabores');
			modalRemoveSabor($('#seuProduto .box3'));
		}
		else
		{
			$('#seuProduto').removeClass('doisSabores umSabor').addClass('tresSabores');
		}
	}});
	
	
	//SLIDER TAMANHO - PRECISA QUE O SLIDER SABORES SEJA INICIALIZADO ANTES
	$('.sliderTamanhos').slider({range: 'max',min: 1,max: modalTamanhoArray.length,value:1,slide: function(event,ui)
	{
		$('#seuProduto .aviso').css({'display':'none'})
		modalTamanho = modalTamanhoArray[ui.value -1];
		
		var saboresValue = $('#monteProduto .sliderSabores').slider("value");
		
		
		if($('body').hasClass("pizza") || $('body').hasClass("pizzadoce"))
		{
			var checkboxBordaCatupiry	= $("#monteProduto input:checkbox[value='Borda Recheada Catupiry']");
			var checkboxBordaCheddar	= $("#monteProduto input:checkbox[value='Borda Recheada Cheddar']");
			var checkboxBordaChocolate	= $("#monteProduto input:checkbox[value='Borda Recheada Chocolate']");
			
			
			if(ui.value == 1)//brotinho
			{
				$('#monteProduto .sabores:eq(0)').css({"display":"block"});
				$('#monteProduto .sabores:eq(1)').css({"display":"none"});
				$('#monteProduto .sabores:eq(2)').css({"display":"none"});
			
				$('.sliderSabores').slider({ range: 'max', min: 1, max: 1, value: 1});
				
				//Nova regra brotinho e gigante não tem borda recheada
				checkboxBordaCatupiry.siblings(".jqTransformChecked").removeClass("jqTransformChecked").end().parent().parent().parent().css({"display":"none"});
				checkboxBordaCheddar.siblings(".jqTransformChecked").removeClass("jqTransformChecked").end().parent().parent().parent().css({"display":"none"});
				checkboxBordaChocolate.siblings(".jqTransformChecked").removeClass("jqTransformChecked").end().parent().parent().parent().css({"display":"none"});
				
				if(modalOpcionaisArray.indexOf("Borda Recheada Catupiry") != -1)
				{
					modalOpcionaisArray.splice(modalOpcionaisArray.indexOf("Borda Recheada Catupiry"),1);	
				}
				if(modalOpcionaisArray.indexOf("Borda Recheada Cheddar") != -1)
				{
					modalOpcionaisArray.splice(modalOpcionaisArray.indexOf("Borda Recheada Cheddar"),1);
				}
				if(modalOpcionaisArray.indexOf("Borda Recheada Chocolate") != -1)
				{
					modalOpcionaisArray.splice(modalOpcionaisArray.indexOf("Borda Recheada Chocolate"),1);
				}
				
			}
			else if(ui.value == 2 || ui.value == 3)//média, grande
			{
				$('#monteProduto .sabores:eq(0)').css({"display":"none"});
				$('#monteProduto .sabores:eq(1)').css({"display":"block"});
				$('#monteProduto .sabores:eq(2)').css({"display":"none"});
				
				if(saboresValue >= 2) { saboresValue = 2 }
				$('.sliderSabores').slider({ range: 'max', min: 1, max: 2, value: saboresValue});
				
				checkboxBordaCatupiry.parent().parent().parent().css({"display":"block"});
				checkboxBordaCheddar.parent().parent().parent().css({"display":"block"});
				checkboxBordaChocolate.parent().parent().parent().css({"display":"block"});
			}
			else if(ui.value == 4)//gigante
			{
				$('#monteProduto .sabores:eq(0)').css({"display":"none"});
				$('#monteProduto .sabores:eq(1)').css({"display":"none"});
				$('#monteProduto .sabores:eq(2)').css({"display":"block"});
			
				$('.sliderSabores').slider({ range: 'max', min: 1, max: 3, value: saboresValue});
				
				//Nova regra brotinho e gigante não tem borda recheada
				checkboxBordaCatupiry.siblings(".jqTransformChecked").removeClass("jqTransformChecked").end().parent().parent().parent().css({"display":"none"});
				checkboxBordaCheddar.siblings(".jqTransformChecked").removeClass("jqTransformChecked").end().parent().parent().parent().css({"display":"none"});
				checkboxBordaChocolate.siblings(".jqTransformChecked").removeClass("jqTransformChecked").end().parent().parent().parent().css({"display":"none"});
				
				if(modalOpcionaisArray.indexOf("Borda Recheada Catupiry") != -1)
				{
					modalOpcionaisArray.splice(modalOpcionaisArray.indexOf("Borda Recheada Catupiry"),1);	
				}
				if(modalOpcionaisArray.indexOf("Borda Recheada Cheddar") != -1)
				{
					modalOpcionaisArray.splice(modalOpcionaisArray.indexOf("Borda Recheada Cheddar"),1);
				}
				if(modalOpcionaisArray.indexOf("Borda Recheada Chocolate") != -1)
				{
					modalOpcionaisArray.splice(modalOpcionaisArray.indexOf("Borda Recheada Chocolate"),1);
				}
			}
		}
		else if($('body').hasClass("focaccia"))
		{
			//
		}
		
		
	}});
	
	
	//APPLY JQTRANSFORM
	$("#monteProduto").jqTransform();
	
	
	//INSERE PRIMEIRO SABOR NA IMAGEM E NO ARRAY
	modalSaboresArray = new Array();
	modalAddSabor(_nomeProduto);
	
	
	//REMOVE SABOR DA IMAGEM E DO ARRAY
	$('#seuProduto .btnExcluir').click(function(){ modalRemoveSabor($(this).parent()) });
	
	
	//BOTÃO OK
	$('#monteProduto .btnOk').click(function()
	{
		//VERIFICAÇÃO DA MONTAGEM
		if(modalQtdeSabores > modalSaboresArray.length)
		{
			var saboresLeft = modalQtdeSabores - modalSaboresArray.length;
			var textoSabores;
			saboresLeft > 1? textoSabores = "sabores": textoSabores="sabor"	
			$('#seuProduto .aviso').css({'display':'block'}).html("Você precisa adicionar mais "+saboresLeft+" "+textoSabores+"!");
		}
		else if( $('body').hasClass('focaccia') && modalQtdeSabores > 1 && modalSaboresArray.indexOf("Nº3 - Itália") != -1 )
		{
			$('#seuProduto .aviso').css({'display':'block'}).html("O sabor Nº3 - Itália não pode ser divido!");
		}
		else
		{
			produtoConfig();
		}
	});
	
}


function modalAddSabor(qual)
{
	if( $('body').hasClass("focaccia") && modalQtdeSabores > 1 && qual == "Nº3 - Itália")
	{
		$('#seuProduto .aviso').css({'display':'block'}).html("O sabor "+qual+" não pode ser divido!");
	}
	else
	{
		$('#seuProduto .aviso').css({'display':'none'})
		
		if(modalSaboresArray.length < modalQtdeSabores)
		{
			//alert("add Sabor")
			$("#seuProduto .box"+(modalSaboresArray.length+1)).removeClass('empty').find('span').html(qual);
			modalSaboresArray.push(qual);
		}
		else{
			//alert("overwrite Sabor: "+String(modalQtdeSabores-1))
			$("#seuProduto .box"+modalQtdeSabores).removeClass('empty').find('span').html(qual);
			modalSaboresArray[modalQtdeSabores-1] = qual;
		}
	}
}


function modalRemoveSabor(_this)
{
	var myName = _this.find('span').html();
	var myIndex = modalSaboresArray.indexOf(myName);
	
	if(myIndex != -1) // Se encontrar no array (se não for "Selecione um sabor")
	{
		//REMOVE FROM ARRAY
		modalSaboresArray.splice(myIndex,1)
		
		//REMOVE FROM PIZZA (CLEAN AND REPOPULATE)
		$("#seuProduto .box1,#seuProduto .box2,#seuProduto .box3").removeClass("empty").addClass("empty").find("span").html("Selecione um sabor");
		for(var ts = 0; ts < modalSaboresArray.length; ts++)
		{
			$("#seuProduto .box"+String(ts+1)).removeClass("empty").find("span").html(modalSaboresArray[ts]);
		}
	}
}


function produtoConfig()
{
	/*RESULTADO
	var opcionaisStr = "";
	if(modalOpcionaisArray.length > 0)
	{
		opcionaisStr += "Opcionais: <br/>"
		for(var i=0; i<modalOpcionaisArray.length; i++)
		{
			opcionaisStr += modalOpcionaisArray[i]+"<br/>"
		}
	}
	
	$('#tracebox')
	.html(	'Tamanho: '+modalTamanho+'<br/>'+
			'Qtde Sabores: '+modalQtdeSabores+'<br/>'+
			'Sabores: '+modalSaboresArray+'<br/>'+
			opcionaisStr+'<br/>');
	*/
	
	var produtoDiv = "";
	var produtoNome = "";
	var produtoDesc = "";
	var produtoOpcionais = "";
	
	if($('body').hasClass('pizza')){ produtoNome += "Pizza "}
	if($('body').hasClass('pizzadoce')){ produtoNome += "Pizza Doce "}
	if($('body').hasClass('focaccia')){ produtoNome += "Focaccia "}
	
	//PRODUTO DESC
	if(modalOpcionaisArray.length > 0)
	{
		produtoOpcionais += "<li>Opcionais: ";
		
		for(var op = 0; op < modalOpcionaisArray.length; op++)
		{
			produtoOpcionais += modalOpcionaisArray[op];
			
			if(op < modalOpcionaisArray.length - 1)
			{
				produtoOpcionais += ", ";
			}
		}
		produtoOpcionais += "</li>";
	}
	
	produtoDesc =	"<ul class='desc'>"+
						"<li>Tamanho: "+modalTamanho+"</li>"+
						produtoOpcionais+
					"</ul>";
	
	//VERIFICAR SE SABORES FOREM TODOS IGUAIS
	for(var sbrs = 0; sbrs < modalSaboresArray.length; sbrs++)
	{
		if(sbrs > 0)
		{
			//TODOS OS SABORES NÃO SÃO IGUAIS - PROSSEGUIR
			if(modalSaboresArray[sbrs] != modalSaboresArray[sbrs-1])
			{		
				//alert("Todos os sabores diferentes");
				if(modalQtdeSabores == 2)		{ produtoDiv = "1/2" }
				else if(modalQtdeSabores == 3)	{ produtoDiv = "1/3" }
				
				for(var i = 0; i < modalQtdeSabores; i++)
				{
					produtoNome += produtoDiv+" "+modalSaboresArray[i];
					if(i < modalQtdeSabores-1) { produtoNome += " + "; }
				}
				
				pedidoInsert(produtoNome,produtoDesc);
				break;	
			}
			else
			{
				//TODOS OS SABORES SÃO IGUAIS
				if(sbrs == modalSaboresArray.length-1)
				{
					//alert("Todos os sabores iguais");
					produtoNome += modalSaboresArray[sbrs];
					pedidoInsert(produtoNome,produtoDesc);
				}
			}
		}
		else
		{
			//APENAS UM SABOR - PROSSEGUIR
			if(sbrs == modalSaboresArray.length-1)
			{
				//alert("Apenas 1 sabor");
				produtoNome += modalSaboresArray[sbrs];
				pedidoInsert(produtoNome,produtoDesc);
			}
		}
	}
	
}


function pedidoInsert(_prodName,_prodDesc)
{
	fechaModal();
	
	//OPEN LISTA PEDIDOS
	if( $("#listaPedidos").css('display') == "none")
	{
		$('#header .pedidos').trigger('click');
	}
	
	
	//MONTA LI
	$("#listaPedidos .pedido")
	.append(	"<li>"+
					"<label class='qtde'><input type='text' maxlength='2' value='1'/>&nbsp;&nbsp;Qtde.</label>"+
					"<div class='btnRemove'></div>"+
					"<h5>"+_prodName+"</h5>"+
					_prodDesc+
				"</li>")
	.find('.btnRemove').click(function()
	{
		$(this).parent().remove();
		//SALVAR PEDIDOS EM COOKIE
		$.cookie('baggio-pedido', $("#listaPedidos .pedido").html());  
	})
	
	
	//SALVAR PEDIDOS EM COOKIE
	$.cookie('baggio-pedido', $("#listaPedidos .pedido").html());  
	
}



/*URL HASH
====================================================================================*/
$.extend(
{
	getUrlVars: function()
	{
		var vars = [], hash;
		var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
		for(var i = 0; i < hashes.length; i++)
		{
			hash = hashes[i].split('=');
			vars.push(hash[0]);
			vars[hash[0]] = hash[1];
		}
		return vars;
	},
	getUrlVar: function(name){
	return $.getUrlVars()[name];
	}
});



/*Javascript Support Array.indexOf in IE
====================================================================================*/
if (!Array.indexOf) {
  Array.prototype.indexOf = function (obj, start) {
    for (var i = (start || 0); i < this.length; i++) {
      if (this[i] == obj) {
        return i;
      }
    }
    return -1;
  }
}


/*IE DETECTION
====================================================================================*/
//http://msdn.microsoft.com/en-us/library/ms537509%28v=vs.85%29.aspx
function getInternetExplorerVersion()
// Returns the version of Internet Explorer or a -1
// (indicating the use of another browser).
{
  var rv = -1; // Return value assumes failure.
  if (navigator.appName == 'Microsoft Internet Explorer')
  {
    var ua = navigator.userAgent;
    var re  = new RegExp("MSIE ([0-9]{1,}[\.0-9]{0,})");
    if (re.exec(ua) != null)
      rv = parseFloat( RegExp.$1 );
  }
  return rv;
}
function checkVersion()
{
  var msg = "You're not using Internet Explorer.";
  var ver = getInternetExplorerVersion();

  if ( ver > -1 )
  {
    if ( ver >= 8.0 ) 
      msg = "You're using a recent copy of Internet Explorer."
    else
      msg = "You should upgrade your copy of Internet Explorer.";
  }
  alert( msg );
}





