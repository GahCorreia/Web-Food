<? include ("conexao.php"); ?>
<?
	session_start();
	$login=$_POST['login'];
	$senha=$_POST['senha'];
	$_SESSION['login']=$_POST['login'];
	$_SESSION['senha']=$_POST['senha'];

	$query = mysql_query("SELECT * FROM `funcionario` WHERE login = '$login'");
	$result = mysql_fetch_array($query);
	if($result){
		header('location:formproduto.php');
	}
	else{
		header('location:login.php');
	}

?>