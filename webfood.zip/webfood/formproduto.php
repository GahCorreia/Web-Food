<!DOCTYPE html>
<html ="lang pt-br">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Cadastro Produto</title>

  <!-- CSS -->
  <link type="text/css" rel="stylesheet" href="css/contato-cadastro.css" />
  <!-- JS -->
  <script type="text/javascript" src="js/jquery-1.4.2.min.js"></script>
  <script type="text/javascript" src="js/jquery.cookie.js"></script>
  <script type="text/javascript" src="js/jquery.ui.widget.js"></script>
  <script type="text/javascript" src="js/jquery.ui.core.js"></script>
  <script type="text/javascript" src="js/jquery.ui.mouse.js"></script>
  <script type="text/javascript" src="js/jquery.ui.slider.js"></script>
  <script type="text/javascript" src="js/jquery.ui.tabs.js"></script>
  <script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
  <script type="text/javascript" src="js/jquery.mousewheel.min.js"></script>
  <script type="text/javascript" src="js/hoverIntent.js"></script>
  <script type="text/javascript" src="js/jcarousellite_1.0.1.min.js"></script>
  <script type="text/javascript" src="js/jquery.jqtransform.js" ></script>
  <script type="text/javascript" src="js/jquery.jscrollpane.min.js"></script>
  <script type="text/javascript" src="js/utils.js"></script>
  <script type="text/javascript" src="js/jquery.validate.min.js"></script>
  <script type="text/javascript" src="js/jquery.ezpz_tooltip.min.js"></script>

  <!--GA-->

</head>


<body class="interno contato">

  <!--BG-->
  <div id="bg"></div>

  <!--HEADER-->
  <div id="header"></div>

  <!--FAIXA-->
  <div id="faixa">
   <div id="faixaBox">
    <h1>CADASTRO</h1>
    <a class="btnVoltar" href="javascript:history.go(-1)">VOLTAR</a>
  </div>
</div>

<!--CONTENT-->
<div id="content">
 <div id="contentBox">
  <br />
  <div class="wireBox cadastroForm">
    <h2>CADASTRE-SE</h2>
    <div class="container">
      <br />
      <form action="incluiproduto.php" method="get"  accept-charset="utf-8">
        <fieldset>
          <label class="w4 req">Nome<input name="nome" type="text"/></label>
          <label class="w4 req">Marca<input name="marca" type="text"/></label>
          <label class="w2 req">Tipo <select name="tipo">
            <option name="tipo" value="bebida">Bebibda</option>
            <option name="tipo" value="comida">Comida</option>
          </select>
        </label>
        <label class="w2 req">Quantidade<select name="quantidade">
          <?php
          for ($i=1; $i<=100; $i++)
          {
            ?>
            <option name="quantidade" value="<?php echo $i;?>"><?php echo $i;?></option>
            <?php
          }
          ?>
        </select>
      </label>
    </fieldset>
    <fieldset>
      <input type="submit" name="submit" value="ENVIAR"/>
      <input type="reset" name="reset" value="LIMPAR"/>
    </fieldset>
  </form>
</div>
</div>
</div>
</div>

<!--FOOTER-->
<div id="footer"></div>

</body>
</html>