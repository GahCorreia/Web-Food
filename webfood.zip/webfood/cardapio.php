<!DOCTYPE html>
<html ="lang pt-br">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Cardapio</title>

  <!-- CSS -->
  <link type="text/css" rel="stylesheet" href="css/contato-cadastro.css" />

  <!-- JS -->
  <script type="text/javascript" src="js/jquery-1.4.2.min.js"></script>
  <script type="text/javascript" src="js/jquery.cookie.js"></script>
  <script type="text/javascript" src="js/jquery.ui.widget.js"></script>
  <script type="text/javascript" src="js/jquery.ui.core.js"></script>
  <script type="text/javascript" src="js/jquery.ui.mouse.js"></script>
  <script type="text/javascript" src="js/jquery.ui.slider.js"></script>
  <script type="text/javascript" src="js/jquery.ui.tabs.js"></script>
  <script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
  <script type="text/javascript" src="js/jquery.mousewheel.min.js"></script>
  <script type="text/javascript" src="js/hoverIntent.js"></script>
  <script type="text/javascript" src="js/jcarousellite_1.0.1.min.js"></script>
  <script type="text/javascript" src="js/jquery.jqtransform.js" ></script>
  <script type="text/javascript" src="js/jquery.jscrollpane.min.js"></script>
  <script type="text/javascript" src="js/utils.js"></script>
  <script type="text/javascript" src="js/jquery.validate.min.js"></script>
  <script type="text/javascript" src="js/jquery.ezpz_tooltip.min.js"></script>

  <!--GA-->

</head>


<body class="interno contato">

	<!--BG-->
	<div id="bg"></div>

  <!--HEADER-->
  <div id="header"></div>

  <!--FAIXA-->
  <div id="faixa">
   <div id="faixaBox">
    <h1>CARDÁPIO</h1>
    <a class="btnVoltar" href="javascript:history.go(-1)">VOLTAR</a>
  </div>
</div>

<!--CONTENT-->
<div id="content">
  <div id="contentBox">
    <h1 align="center"> Bem vindo !<br /></h1>
    <div class="wireBox cadastroForm">
      <div class="container">
        <br />
      </div>
    </div>
  </div>
</div>
<!--FOOTER-->
<div id="footer"></div>
</body>
</html>