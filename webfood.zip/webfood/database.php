<?php
	//Excluir registros
	function DBDelete($table, $where){

		$query = "DELETE FROM {$table} WHERE {$where}";
		return DBExecute($query);
	}

	//ler registros
	function DBSelect($table, $params = null, $fields = '*'){
		$params = ($params) ? " {$params}" : null;

		$query = "SELECT {$fields} FROM {$table}{$params}";
		$result=DBExecute($query);

		if(!mysqli_num_rows($result)){
			return false;
		}
		else {
			while($res = mysqli_fetch_assoc($result)){
				$dados[] =$res;
			}
			return $dados;
		}
	}
	//Alterar registros
	function DBUpdate($table, array $dados, $where = null){
		foreach ($dados as $key => $value){
		$fields[] = "{$key} ='{$value}'" ;
		}
		 $fields= implode(', ', $fields);
		$where = ($where) ? " WHERE {$where}" : null;
		$query = "UPDATE {$table} SET {$fields}{$where}";

		return DBExecute($query);
	}
	//Insere na tabela selecionada
	function DBInsert($table, $dados){
		$dados = DBEscape($dados);
	     $fields= implode (', ', array_keys($dados)) ;
		 $values= "'".implode ("', '", $dados)."'";

		$query = "INSERT INTO {$table}({$fields}) values ({$values})";
		return DBExecute($query);
	}

	//Executa Query
	function DBExecute($query){
		$connect = DBconnect();
		$result = @mysqli_query($connect, $query) or die (mysqli_error($connect));
		DBclose($connect);
		return $result;
	}
?>